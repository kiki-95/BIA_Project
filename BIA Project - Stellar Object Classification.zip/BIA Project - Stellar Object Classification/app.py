# Importing necessary libraries
import streamlit as st
import numpy as np
from joblib import load

# Filter warnings
import warnings
warnings.filterwarnings('ignore')

# Load joblib model (use caching if the model file is large)
@st.cache_resource
def load_model():
    try:
        return load('XGBoost.joblib')
    except FileNotFoundError:
        st.error("Model file not found. Please upload the 'XGBoost.joblib' file.")
        return None

# Title for the App
st.title("Stellar Object Classification App")

# Add link to SDSS image gallery
st.markdown("### Explore Stellar Images")
st.markdown("Check out the [SDSS Image Gallery](https://www.sdss4.org/science/image-gallery/) for stunning images of galaxies, stars, and quasars.")

# UI for input details
st.header("Enter the below details:")

# Input fields
alpha = st.number_input("Right Ascension angle:")
delta = st.number_input("Declination angle:")
u = st.number_input("Enter Ultraviolet filter value:")
g = st.number_input("Enter Green filter value:")
r = st.number_input("Enter Red filter value:")
i = st.number_input("Enter Near Infrared filter value:")
z = st.number_input("Enter Infrared filter value:")
cam_col = st.selectbox("Camera column", (1, 2, 3, 4, 5, 6))
redshift = st.number_input("Enter the redshift value:")
plate = st.number_input("Enter the Plate ID:", step=1, format="%d")
MJD = st.number_input("Enter the modified Julian Date:", step=1, format="%d")

# Load model once at the beginning
model = load_model()
if not model:
    st.stop()  # Stop execution if the model is not loaded

# Prediction button
if st.button("Classify Object"):
    # Prepare input as a 2D array for prediction
    input_features = np.array([[alpha, delta, u, g, r, i, z, cam_col, redshift, plate, MJD]])

    # Perform prediction
    try:
        prediction = model.predict(input_features)

        # Display result based on prediction
        st.header("Prediction Result")
        if prediction[0] == 0:
            st.success("The object is a Galaxy")
            st.image("https://www.sdss.org/wp-content/uploads/2020/12/spiral_galaxy.jpg", caption="Example of a Galaxy", use_column_width=True)
        elif prediction[0] == 1:
            st.success("The object is a Star")
            st.image("https://www.sdss.org/wp-content/uploads/2020/12/star.jpg", caption="Example of a Star", use_column_width=True)
        elif prediction[0] == 2:
            st.success("The object is a QSO")
            st.image("https://www.sdss.org/wp-content/uploads/2020/12/qso.jpg", caption="Example of a QSO", use_column_width=True)
        else:
            st.error("Prediction not recognized, please check the model.")

    except Exception as e:
        st.error(f"An error occurred during prediction: {e}")
