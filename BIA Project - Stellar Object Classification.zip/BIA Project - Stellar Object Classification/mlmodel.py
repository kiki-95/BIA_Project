# Import necessary libraries
import streamlit as st
from transformers import pipeline
from PIL import Image

# Title for the App
st.title("Stellar Object Classification with Hugging Face")

# Load the pre-trained Hugging Face model (image classification model)
classifier = pipeline("image-classification", model="google/vit-base-patch16-224-in21k")  # Example: Vision Transformer (ViT)

# Upload image file
uploaded_image = st.file_uploader("Upload an image for classification", type=["jpg", "png", "jpeg"])

# Prediction button
if uploaded_image is not None and st.button("Classify Object"):
    try:
        # Open and process the uploaded image
        image = Image.open(uploaded_image)
        
        # Use the Hugging Face model to classify the image
        predictions = classifier(image)
        
        # Display result
        st.header("Prediction Result")
        
        # Get the predicted label and confidence score
        label = predictions[0]['label']
        score = predictions[0]['score']
        
        st.success(f"The object is classified as: {label} with a confidence score of {score:.2f}")
        
        # Display the image
        st.image(image, caption="Uploaded Image", use_column_width=True)
        
    except Exception as e:
        st.error(f"An error occurred during prediction: {e}")
