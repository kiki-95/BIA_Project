import streamlit as st
import numpy as np
from joblib import load

# Importing necessary libraries
import warnings
warnings.filterwarnings('ignore')

# Load joblib model
try:
    model = load('XGBoost.joblib')  # Load the pre-trained XGBoost model
except FileNotFoundError:
    st.error("Model file not found. Please upload the 'XGBoost.joblib' file.")

# Mapping numeric labels to class names
label_mapping = {
    0: "Galaxy",
    1: "Star",
    2: "QSO"
}

# Function to handle input and predictions
def classify_object():
    # User input fields for features
    alpha = st.number_input("Right Ascension angle:")
    delta = st.number_input("Declination angle:")
    u = st.number_input("Enter Ultraviolet filter value:")
    g = st.number_input("Enter Green filter value:")
    r = st.number_input("Enter Red filter value:")
    i = st.number_input("Enter Near Infrared filter value:")
    z = st.number_input("Enter Infrared filter value:")
    cam_col = st.selectbox("Camera column", (1, 2, 3, 4, 5, 6))
    redshift = st.number_input("Enter the redshift value:")
    plate = st.number_input("Enter the Plate ID:", step=1, format="%d")
    MJD = st.number_input("Enter the modified Julian Date:", step=1, format="%d")
    
    # Prepare the input as a 2D array
    input_features = np.array([[alpha, delta, u, g, r, i, z, cam_col, redshift, plate, MJD]])
    
    # If the classify button is pressed
    if st.button("Classify Object"):
        try:
            # Perform prediction
            prediction = model.predict(input_features)

            # Map the numeric label to a class name
            predicted_class = label_mapping.get(prediction[0], "Unknown")

            # Display the prediction result
            st.header("Prediction Result")
            st.success(f"The object is a {predicted_class}")

            # Display corresponding image based on the prediction
            if predicted_class == "Galaxy":
                st.image("https://www.sdss.org/wp-content/uploads/2020/12/spiral_galaxy.jpg", caption="Example of a Galaxy", use_column_width=True)
            elif predicted_class == "Star":
                st.image("https://www.sdss.org/wp-content/uploads/2020/12/star.jpg", caption="Example of a Star", use_column_width=True)
            elif predicted_class == "QSO":
                st.image("https://www.sdss.org/wp-content/uploads/2020/12/qso.jpg", caption="Example of a QSO", use_column_width=True)

        except Exception as e:
            st.error(f"An error occurred during prediction: {e}")

# Title for the app
st.title("Stellar Object Classification App")

# Add information about SDSS
st.markdown("### Explore Stellar Images")
st.markdown("Check out the [SDSS Image Gallery](https://www.sdss4.org/science/image-gallery/) for stunning images of galaxies, stars, and quasars.")

# Call the function to classify the object
classify_object()
