import streamlit as st
import numpy as np
from joblib import load

def load_model():
    try:
        return load('XGBoost.joblib')
    except FileNotFoundError:
        st.error("Model file not found. Please upload the 'XGBoost.joblib' file.")
        return None

# Get user input
def get_user_input():
    return np.array([[st.slider("Right Ascension angle:", 0.0, 360.0, step=0.1),
                      st.slider("Declination angle:", -90.0, 90.0, step=0.1),
                      st.slider("Ultraviolet filter:", 0.0, 30.0, step=0.1),
                      st.slider("Green filter:", 0.0, 30.0, step=0.1),
                      st.slider("Red filter:", 0.0, 30.0, step=0.1),
                      st.slider("Near Infrared filter:", 0.0, 30.0, step=0.1),
                      st.slider("Infrared filter:", 0.0, 30.0, step=0.1),
                      st.selectbox("Camera column", (1, 2, 3, 4, 5, 6)),
                      st.slider("Redshift:", 0.0, 5.0, step=0.01),
                      st.slider("Plate ID:", 0, 10000),
                      st.slider("MJD:", 50000, 60000)]])  # Return input as 2D array

# Display result
def display_result(prediction):
    result = {0: "Galaxy", 1: "Star", 2: "QSO"}
    st.success(f"The object is a {result.get(prediction[0], 'Unknown')}")

def main():
    st.title("Stellar Object Classification")
    model = load_model()
    if not model:
        return

    input_features = get_user_input()
    if st.button("Classify Object"):
        prediction = model.predict(input_features)
        display_result(prediction)

if __name__ == "__main__":
    main()