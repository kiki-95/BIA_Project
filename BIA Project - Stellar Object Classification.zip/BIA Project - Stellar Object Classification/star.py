import streamlit as st

# Image URLs from Unsplash (replace these with your preferred images)
star_image_url = "https://images.unsplash.com/photo-1566739060-80d51f4773da"  # Example URL for star image
quasar_image_url = "https://images.unsplash.com/photo-1567366717-3a4b2b9c10b0"  # Example URL for quasar image
galaxy_image_url = "https://images.unsplash.com/photo-1604980898972-580eb6c3f169"  # Example URL for galaxy image

# Displaying the images using st.image with use_container_width parameter
st.title('Astronomical Object Classification')
st.write("### Star Example")
st.image(star_image_url, use_container_width=True)  # Image of a star

st.write("### Quasar Example")
st.image(quasar_image_url, use_container_width=True)  # Image of a quasar

st.write("### Galaxy Example")
st.image(galaxy_image_url, use_container_width=True)  # Image of a galaxy
